﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace First
{

        class Employee
        {
            public int EmpID { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Designation { get; set; }
            public DateTime DOB { get; set; }
            public DateTime DOJ { get; set; }
            public string City { get; set; }

        }

        class Launch
        {
            public static List<Employee> empList = new List<Employee>
{


new Employee() {EmpID = 1001,FirstName = "Umesh",LastName = "yadav",Designation = "Manager",DOB = DateTime.Parse("1984-01-02"),DOJ = DateTime.Parse("2011-08-09"),City = "Mumbai"},
new Employee() {EmpID = 1002,FirstName = "Meghana",LastName = "koundinya",Designation = "Human Resource",DOB = DateTime.Parse("1984-08-20"),DOJ = DateTime.Parse("2012-7-7"),City = "Mumbai"},
new Employee() {EmpID = 1003,FirstName = "Madhavi",LastName = "madhu",Designation = "Consultant",DOB = DateTime.Parse("1987-11-14"),DOJ = DateTime.Parse("2015-4-12"),City = "Pune"},
new Employee() {EmpID = 1004,FirstName = "Yashu",LastName = "krupakar",Designation = "SE",DOB = DateTime.Parse("6/3/1990"),DOJ = DateTime.Parse("2/2/2016"),City = "Pune"},
new Employee() {EmpID = 1005,FirstName = "Naddu",LastName = "mohammad",Designation = "SE",DOB = DateTime.Parse("3/8/1991"),DOJ = DateTime.Parse("2/2/2016"),City = "Mumbai"},
new Employee() {EmpID = 1006,FirstName = "Hannu",LastName = "Pathak",Designation = "Consultant",DOB = DateTime.Parse("11/7/1989"),DOJ = DateTime.Parse("8/8/2014"),City = "Chennai"},
new Employee() {EmpID = 1007,FirstName = "Vijay",LastName = "shankar",Designation = "Tester",DOB = DateTime.Parse("12/2/1989"),DOJ = DateTime.Parse("6/1/2015"),City = "Mumbai"},
new Employee() {EmpID = 1008,FirstName = "Ashu",LastName = "Dubey",Designation = "Associate",DOB = DateTime.Parse("11/11/1993"),DOJ = DateTime.Parse("11/6/2014"),City = "Chennai"},
new Employee() {EmpID = 1009,FirstName = "Narendra",LastName = "Modi",Designation = "Manager",DOB = DateTime.Parse("8/12/1992"),DOJ = DateTime.Parse("12/3/2014"),City = "Chennai"},
new Employee() {EmpID = 1010,FirstName = "Amit",LastName = "Shah",Designation = "Associate",DOB = DateTime.Parse("4/12/1991"),DOJ = DateTime.Parse("1/2/2016"),City = "Pune"},


};

            public static void Main()
            {
                DisplayAll();
                NotMumbai();
                AsstManager();
                LastNameS();
                Joinedbefore();
                DateOfBirth();
                ConsandAsso();
                TotalEmployees();
                EmpChennai();
                HighestEmployeeId();
            EmpJoinedAfter();
            NotAssociate();

                Console.ReadKey();
            }
            public static void DisplayAll()
            {

                var query = (from e in empList
                             select e);
                foreach (var data in query)
                {
                    Console.WriteLine(data.EmpID + " " + data.FirstName + " " + data.LastName + " " + data.Designation + " " + data.DOB + " " + data.DOJ + " " + data.City);
                }

                Console.WriteLine(".....................................................................");

            }

            public static void NotMumbai()
            {
                var notMumbai = from e in empList where e.City != "Mumbai" select e;
                foreach (var item in notMumbai)
                {
                    Console.WriteLine(item.EmpID + " " + item.FirstName + " " + item.LastName + " " + item.Designation + " " + item.DOB + " " + item.DOJ + " " + item.City);
                }

                Console.WriteLine("......................................................................");
            }

            public static void AsstManager()
            {
                var Asstman = from e in empList where e.Designation == "AsstManager" select e;
                foreach (var data in Asstman)
                {
                    Console.WriteLine(data.EmpID + " " + data.FirstName + " " + data.LastName + "" + data.Designation + " " + data.DOB + " " + data.DOJ + " " + data.City);
                }

                Console.WriteLine("...............................................................");
            }

             public static void LastNameS()
            {
                var LastNameS = from e in empList where e.LastName.StartsWith('U' + "") select e;
                foreach (var data in LastNameS)
                {
                    Console.WriteLine(data.EmpID + " " + data.FirstName + " " + data.LastName + " " + data.Designation + " " + data.DOB + " " + data.DOJ + " " + data.City);

                }
                Console.WriteLine("....................................................................");
            }

            public static void Joinedbefore()
            {
                var joinedbefore = from e in empList where e.DOJ < DateTime.Parse("1/1/2015") select e;
                foreach (var data in joinedbefore)
                {
                    Console.WriteLine(data.EmpID + " " + data.FirstName + " " + data.LastName + " " + data.Designation + " " + data.DOB + " " + data.DOJ + " " + data.City);

                }
                Console.WriteLine("......................................................................");
            }

            public static void DateOfBirth()
            {
                var dateofbirth = from e in empList where e.DOB > DateTime.Parse("1/1/1990") select e;
                foreach (var data in dateofbirth)
                {
                    Console.WriteLine(data.EmpID + " " + data.FirstName + " " + data.LastName + " " + data.Designation + " " + data.DOB + " " + data.DOJ + " " + data.City);

                }
                Console.WriteLine("......................................................................");
            }
       
       
        public static void ConsandAsso()
        {
            var ConsandAsso = (from e in empList where (e.Designation == "Consultant") || (e.Designation == "Associate") select e);
            foreach (var e in ConsandAsso)
            {
                Console.WriteLine(e.EmpID + " " + e.FirstName + " " + e.LastName + " " + e.Designation + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }
            Console.WriteLine(".....................................................................");
        }
        public static void TotalEmployees()
        {
            var totalemployees = empList.Count();
            {
                Console.WriteLine("Total number of Employees: {0}", totalemployees);
            }
            Console.WriteLine(".....................................................................");
        }
        public static void EmpChennai()
        {
            var empChennai = empList.Count(e => e.City == "Chennai");
            { 
            Console.WriteLine("Total number of Employees Belonging to Chennai are: {0}", empChennai);
        }
        Console.WriteLine(".....................................................................");
        }
        public static void HighestEmployeeId()
        {
            var highemployeeid = empList.Max(e => e.EmpID);
            {
                Console.WriteLine("Highest Employee Id is: {0}", highemployeeid);
            }
            Console.WriteLine(".....................................................................");
        }
        public static void EmpJoinedAfter()
        {
            var empjoinedafter = empList.Count(e => e.DOJ > DateTime.Parse("1/1/2015"));
            {
                Console.WriteLine("Total number of Employees Joined After 1/1/2015 is: {0}", empjoinedafter);
             }
            Console.WriteLine(".....................................................................");
        }
            public static void NotAssociate()
        {
            var notasst = empList.Count(e => e.Designation != "Associate");
            {
                Console.WriteLine("Total number of Employees Whose Designation is not Associate is: {0}", notasst);
            }
            Console.WriteLine(".....................................................................");
        }
       


        }
}

         



